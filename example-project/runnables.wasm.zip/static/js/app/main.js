function main() {
	console.log("hey")
}